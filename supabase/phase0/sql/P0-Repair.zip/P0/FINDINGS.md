# Confirmed live database findings

**Evidence capture:** 30 July 2026 19:12 UTC  
**Application reviewed:** V4.0.82  
**Status:** repair package prepared; no database change applied

## Confirmed P0 findings

1. **The persisted role constraint is still the old six-role model.** `public.user_roles_role_check` permits `Admin`, `Inspector`, `Equipment Manager`, `Certificate Approver`, `Office / Reports`, and `Viewer`. The V4.0.82 interface uses `Admin`, `Height equipment manager`, `Height equipment user`, `Maintenance manager`, and `Vehicle inspector`.
2. **The live role data currently contains one row and it is `Admin`.** No live user-role row needs automatic mapping. Pending preloaded-user role arrays were not exposed in the aggregate export, so the preflight script deliberately aborts if an unsupported value exists.
3. **Legacy role names remain throughout public-table and storage policies.** This prevents the new non-Admin roles from receiving the access shown by the interface.
4. **Height read-only access needs explicit database enforcement.** The proposed policies grant Height writes only to Admin and Height equipment manager, while Height equipment user receives SELECT only.
5. **The Height pass trigger is unsafe.** It currently closes every non-completed Height task for the equipment. The replacement closes only related automatic failure tasks, only when the pass is the latest effective inspection.
6. **Automatic Height task sync considers all historical failures.** The replacement generates a Height task only when the failed inspection is the latest effective inspection for that item.
7. **Automatic-task functions are exposed too broadly.** The live grants include `anon` and, for some functions, `PUBLIC`. The package removes anonymous execution and leaves the trigger function owner-only.
8. **The task status database constraint is behind the interface.** The interface and RPC allow `Waiting on Someone`, but the live table constraint does not. The migration adds it.
9. **The hourly cron job is active.** `spray-wash-auto-task-sync` runs at minute 15 of every hour and calls `public.operations_sync_automatic_tasks_v4077()`.
10. **No unresolved Height task group was returned by the aggregate `08g` query.** The migration therefore does not perform a one-time task data rewrite.

## Other live observations

- PostgreSQL 17.6 is reported by the export.
- There are two private storage buckets: `equipment-photos` and `inspection-photos`.
- The export found no public-schema RLS-enabled table without a policy.
- The ten reviewed security-definer functions have an explicit `search_path`.
- Two maintenance-history SELECT policies currently use `USING (true)`; the replacement limits them to Admin, Maintenance manager, and Vehicle inspector, matching V4.0.82 data loading.

## Deliberate safeguards

- The migration refuses to guess how a legacy role should map to a current role.
- It fingerprints the captured live policy names and aborts if the policy catalogue has changed.
- It runs in one transaction with lock and statement timeouts.
- It does not alter app files, storage objects, task descriptions, inspection records, or user content.
- The private raw CSV exports are not included in this package.
