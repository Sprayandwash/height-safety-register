# Application runbook

## Hold point

This package is **review-only**. No SQL has been applied. Do not run the migration until a current Supabase backup/rollback point is confirmed.

## Recommended application sequence

1. Place the app in a short maintenance window. Avoid user creation, inspections, maintenance entries, or role edits during the change.
2. Confirm the live app is still V4.0.82 and no database migration has been applied since the evidence capture.
3. Run `sql/00_preflight_gate.sql`. Stop if it raises any exception.
4. Retain the preflight result privately.
5. Run `sql/01_phase0_database_stabilisation.sql` once.
6. Run `sql/02_post_migration_verification.sql`. Required values:
   - `missing_phase0_policies = 0`
   - `policies_with_legacy_role_mentions = 0`
   - `authenticated_can_sync = true`
   - `anon_can_sync = false`
   - `authenticated_can_call_trigger_function = false`
7. Complete `docs/ROLE-VERIFICATION-CHECKLIST.md` using test accounts for all five roles.
8. Check the cron job after the next minute-15 run and confirm no unexpected tasks were created.
9. Only after verification, add the migration and updated migration ledger to the private development workflow/repository.

## Stop and rollback conditions

Stop immediately if:

- the preflight reports unsupported role values;
- the migration reports policy-catalogue drift;
- Admin loses access;
- a role gains a module it should not see;
- a backdated Height pass closes a newer failure task;
- the hourly sync creates a task for a Height failure followed by a later pass.

Use `sql/90_full_rollback_to_20260730.sql` only before new current-role users or `Waiting on Someone` task rows have been added. The rollback contains its own safety gate and will refuse an unsafe reversal.

## Expected downtime

The migration changes constraints, functions, grants, and policies in one transaction. The catalogue is small, but the table locks require a quiet window. The configured lock timeout is 10 seconds; failure to obtain a lock aborts rather than waiting indefinitely.
