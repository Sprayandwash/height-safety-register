# Phase 0 role and permission matrix

Legend: **R** read, **C** create, **U** update, **D** delete, **Own** only the signed-in user's relevant row/task.

| Area | Admin | Height equipment manager | Height equipment user | Maintenance manager | Vehicle inspector |
|---|---|---|---|---|---|
| App settings | R/C/U/D | R | R | R | R |
| Profiles | All | Own | Own | R all; own update | Own |
| Users and roles | All | Own role read | Own role read | Own role read | Own role read |
| Height equipment/register | R/C/U/D | R/C/U | R | — | — |
| Height equipment and inspection photos | R/C/U/D | R/C/U/D | R | — | — |
| Height inspections | R/C/U/D | R/C/U | R | — | — |
| Qualifications and certificates | R/C/U/D | R/C/U/D | R | — | — |
| Vehicles, machinery and checklist setup | R/C/U/D | — | — | R/C/U/D | R |
| Vehicle inspections and answers | R/C/U/D | — | — | R/U | R/C |
| Operations inspection photos | R/C/U/D | — | — | R/U | R/C |
| Maintenance procedures and schedules | R/C/U/D | — | — | R/C/U/D | R |
| Maintenance history/readings | R/C/U/D | — | — | R/C/U | R; readings C |
| Maintenance-assigned tasks | All | — | — | R/C/U | Own vehicle-check-created tasks R |
| Height-assigned tasks | All | R/C/U | — | — | — |
| Task assigned directly to user | All | Own R/U | Own R/U | Own R/U | Own R/U |
| Company branding storage | R/C/U/D | R | R | R | R |

## Storage path rules

- `equipment-photos`: Height read roles can view; Admin and Height equipment manager can write.
- `inspection-photos/operations-inspections/...`: Admin and Vehicle inspector can write.
- `inspection-photos/operations-assets/...`: Admin and Maintenance manager can write.
- `inspection-photos/height-inspector-qualifications/...` and legacy Height inspection paths: Admin and Height equipment manager can write.
- `inspection-photos/app-branding/...`: Admin can write; all five app roles can read.
