# Evidence manifest

- Combined live catalogue export: received and parsed successfully; 3151 JSON catalogue rows across 32 non-empty sections.
- Function definitions export: received and parsed successfully.
- Trigger export: received and parsed successfully.
- Cron job export: active `spray-wash-auto-task-sync` job confirmed.
- Structural audit: V4.0.82 audit supplied by the user.
- Repository source checked: `operations-v4.js` and `app.js` V4.0.82 role definitions and current data-loading paths.

Private raw exports are not copied into this package.
