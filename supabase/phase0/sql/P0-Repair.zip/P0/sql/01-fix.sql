-- Spray & Wash V4.0.82 — Phase 0 database stabilisation
-- Generated from the live catalogue export captured 30 July 2026.
-- FOR REVIEW FIRST. Apply once, inside a confirmed backup/rollback window.

BEGIN;
SET LOCAL lock_timeout = '10s';
SET LOCAL statement_timeout = '5min';

LOCK TABLE public.user_roles,
           public.operations_preloaded_users,
           public.operations_maintenance_tasks,
           public.inspections
IN SHARE ROW EXCLUSIVE MODE;

-- Abort rather than guess if user or pending-user roles are not already in the five-role model.
DO $$
DECLARE
  v_bad_roles text;
  v_bad_preloaded text;
BEGIN
  SELECT string_agg(DISTINCT role, ', ' ORDER BY role)
  INTO v_bad_roles
  FROM public.user_roles
  WHERE role <> ALL (ARRAY['Admin','Height equipment manager','Height equipment user','Maintenance manager','Vehicle inspector']);

  SELECT string_agg(DISTINCT r, ', ' ORDER BY r)
  INTO v_bad_preloaded
  FROM public.operations_preloaded_users u
  CROSS JOIN LATERAL unnest(coalesce(u.roles, ARRAY[]::text[])) r
  WHERE r <> ALL (ARRAY['Admin','Height equipment manager','Height equipment user','Maintenance manager','Vehicle inspector']);

  IF v_bad_roles IS NOT NULL OR v_bad_preloaded IS NOT NULL THEN
    RAISE EXCEPTION 'Unsupported role values. user_roles=%; preloaded=%',
      coalesce(v_bad_roles,'none'), coalesce(v_bad_preloaded,'none');
  END IF;
END $$;

CREATE TEMP TABLE phase0_expected_live_policies (
  schemaname text NOT NULL,
  tablename text NOT NULL,
  policyname text NOT NULL,
  PRIMARY KEY (schemaname, tablename, policyname)
) ON COMMIT DROP;

INSERT INTO phase0_expected_live_policies(schemaname, tablename, policyname) VALUES
    ('public', 'app_settings', 'app settings admin insert'),
    ('public', 'app_settings', 'app settings admin update'),
    ('public', 'app_settings', 'app settings select approved'),
    ('public', 'audit_logs', 'audit logs insert approved users'),
    ('public', 'audit_logs', 'audit logs select admin reports'),
    ('public', 'certificates', 'certificates v34 delete admin'),
    ('public', 'certificates', 'certificates v34 insert cert roles'),
    ('public', 'certificates', 'certificates v34 select approved'),
    ('public', 'certificates', 'certificates v34 update cert roles'),
    ('public', 'equipment', 'equipment v34 delete admin'),
    ('public', 'equipment', 'equipment v34 insert managers'),
    ('public', 'equipment', 'equipment v34 select approved'),
    ('public', 'equipment', 'equipment v34 update managers'),
    ('public', 'equipment_photos', 'equipment photos v34 delete photo roles'),
    ('public', 'equipment_photos', 'equipment photos v34 insert photo roles'),
    ('public', 'equipment_photos', 'equipment photos v34 select approved'),
    ('public', 'equipment_photos', 'equipment photos v34 update photo roles'),
    ('public', 'height_inspector_qualifications', 'height inspector quals insert approved'),
    ('public', 'height_inspector_qualifications', 'height inspector quals select approved'),
    ('public', 'height_inspector_qualifications', 'height inspector quals update managers'),
    ('public', 'inspection_photos', 'inspection photos v34 delete inspectors'),
    ('public', 'inspection_photos', 'inspection photos v34 insert inspectors'),
    ('public', 'inspection_photos', 'inspection photos v34 select approved'),
    ('public', 'inspection_photos', 'inspection photos v34 update inspectors'),
    ('public', 'inspections', 'inspections v34 delete admin'),
    ('public', 'inspections', 'inspections v34 insert inspectors'),
    ('public', 'inspections', 'inspections v34 select approved'),
    ('public', 'inspections', 'inspections v34 update inspectors'),
    ('public', 'operations_checklist_items', 'ops items manage managers'),
    ('public', 'operations_checklist_items', 'ops items select approved'),
    ('public', 'operations_checklist_templates', 'ops templates manage managers'),
    ('public', 'operations_checklist_templates', 'ops templates select approved'),
    ('public', 'operations_equipment_maintenance_schedules', 'ops schedules manage managers'),
    ('public', 'operations_equipment_maintenance_schedules', 'ops schedules select approved'),
    ('public', 'operations_inspection_answers', 'ops answers insert inspectors'),
    ('public', 'operations_inspection_answers', 'ops answers select approved'),
    ('public', 'operations_inspection_photos', 'ops photos insert inspectors'),
    ('public', 'operations_inspection_photos', 'ops photos select approved'),
    ('public', 'operations_inspections', 'ops inspections insert inspectors'),
    ('public', 'operations_inspections', 'ops inspections select approved'),
    ('public', 'operations_inspections', 'ops inspections update managers'),
    ('public', 'operations_maintenance_log', 'Authenticated users can add maintenance log'),
    ('public', 'operations_maintenance_log', 'Authenticated users can read maintenance log'),
    ('public', 'operations_maintenance_log', 'Maintenance managers can add maintenance log'),
    ('public', 'operations_maintenance_log_items', 'Authenticated users can read maintenance log items'),
    ('public', 'operations_maintenance_log_items', 'Maintenance managers can add maintenance log items'),
    ('public', 'operations_maintenance_parts_used', 'Responsible roles can add task parts'),
    ('public', 'operations_maintenance_parts_used', 'Responsible roles can view task parts'),
    ('public', 'operations_maintenance_procedure_steps', 'ops procedure steps manage managers'),
    ('public', 'operations_maintenance_procedure_steps', 'ops procedure steps select approved'),
    ('public', 'operations_maintenance_procedures', 'ops procedures manage managers'),
    ('public', 'operations_maintenance_procedures', 'ops procedures select approved'),
    ('public', 'operations_maintenance_readings', 'ops readings insert approved'),
    ('public', 'operations_maintenance_readings', 'ops readings select approved'),
    ('public', 'operations_maintenance_task_steps', 'Responsible roles can add task steps'),
    ('public', 'operations_maintenance_task_steps', 'Responsible roles can view task steps'),
    ('public', 'operations_maintenance_tasks', 'Admins can delete shared tasks'),
    ('public', 'operations_maintenance_tasks', 'Responsible roles can create shared tasks'),
    ('public', 'operations_maintenance_tasks', 'Responsible roles can update shared tasks'),
    ('public', 'operations_maintenance_tasks', 'Shared tasks are visible to responsible roles'),
    ('public', 'operations_preloaded_users', 'ops preloaded users admin manage'),
    ('public', 'operations_preloaded_users', 'ops preloaded users self read'),
    ('public', 'operations_vehicles', 'ops vehicles manage managers'),
    ('public', 'operations_vehicles', 'ops vehicles select approved'),
    ('public', 'operations_washing_equipment', 'ops washing equipment manage managers'),
    ('public', 'operations_washing_equipment', 'ops washing equipment select approved'),
    ('public', 'profiles', 'profiles insert self or admin'),
    ('public', 'profiles', 'profiles select self or admin'),
    ('public', 'profiles', 'profiles update self or admin'),
    ('public', 'user_roles', 'user roles delete admin'),
    ('public', 'user_roles', 'user roles insert admin'),
    ('public', 'user_roles', 'user roles select self or admin'),
    ('public', 'user_roles', 'user roles update admin'),
    ('storage', 'objects', 'storage equipment photos v34 delete'),
    ('storage', 'objects', 'storage equipment photos v34 insert'),
    ('storage', 'objects', 'storage equipment photos v34 select'),
    ('storage', 'objects', 'storage equipment photos v34 update'),
    ('storage', 'objects', 'storage inspection photos v34 delete'),
    ('storage', 'objects', 'storage inspection photos v34 insert'),
    ('storage', 'objects', 'storage inspection photos v34 select'),
    ('storage', 'objects', 'storage inspection photos v34 update');

DO $$
DECLARE
  v_missing text;
  v_unexpected text;
BEGIN
  SELECT string_agg(format('%I.%I / %I', e.schemaname, e.tablename, e.policyname), E'\n')
  INTO v_missing
  FROM phase0_expected_live_policies e
  LEFT JOIN pg_policies p
    ON p.schemaname=e.schemaname AND p.tablename=e.tablename AND p.policyname=e.policyname
  WHERE p.policyname IS NULL;

  SELECT string_agg(format('%I.%I / %I', p.schemaname, p.tablename, p.policyname), E'\n')
  INTO v_unexpected
  FROM pg_policies p
  WHERE (
      p.schemaname='public'
      OR (p.schemaname='storage' AND p.tablename='objects')
    )
    AND EXISTS (
      SELECT 1 FROM phase0_expected_live_policies e
      WHERE e.schemaname=p.schemaname AND e.tablename=p.tablename
    )
    AND NOT EXISTS (
      SELECT 1 FROM phase0_expected_live_policies e
      WHERE e.schemaname=p.schemaname AND e.tablename=p.tablename AND e.policyname=p.policyname
    );

  IF v_missing IS NOT NULL OR v_unexpected IS NOT NULL THEN
    RAISE EXCEPTION 'Policy catalogue has changed since the Phase 0 export. Missing:% Unexpected:%',
      coalesce(E'\n'||v_missing, ' none'), coalesce(E'\n'||v_unexpected, ' none');
  END IF;
END $$;

-- Align persisted role values and future preloaded users with the V4.0.82 interface.
ALTER TABLE public.user_roles DROP CONSTRAINT IF EXISTS user_roles_role_check;
ALTER TABLE public.user_roles
  ADD CONSTRAINT user_roles_role_check
  CHECK (role = ANY (ARRAY['Admin','Height equipment manager','Height equipment user','Maintenance manager','Vehicle inspector']::text[]));

ALTER TABLE public.operations_preloaded_users
  ALTER COLUMN roles SET DEFAULT ARRAY[]::text[];
ALTER TABLE public.operations_preloaded_users
  DROP CONSTRAINT IF EXISTS operations_preloaded_users_roles_check;
ALTER TABLE public.operations_preloaded_users
  ADD CONSTRAINT operations_preloaded_users_roles_check
  CHECK (coalesce(roles, ARRAY[]::text[]) <@ ARRAY['Admin','Height equipment manager','Height equipment user','Maintenance manager','Vehicle inspector']::text[]);

-- The app and task RPC both expose Waiting on Someone; the live table constraint did not.
ALTER TABLE public.operations_maintenance_tasks
  DROP CONSTRAINT IF EXISTS operations_maintenance_tasks_status_check;
ALTER TABLE public.operations_maintenance_tasks
  ADD CONSTRAINT operations_maintenance_tasks_status_check
  CHECK (status = ANY (ARRAY['Open','In Progress','Waiting on Parts','Waiting on Someone','Completed','Deferred']::text[]));

CREATE OR REPLACE FUNCTION public.claim_preloaded_user_setup()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_user uuid := auth.uid();
  v_email text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_pre public.operations_preloaded_users%rowtype;
  v_role text;
BEGIN
  IF v_user IS NULL OR v_email = '' THEN
    RETURN;
  END IF;

  SELECT * INTO v_pre
  FROM public.operations_preloaded_users
  WHERE lower(email) = v_email
    AND active = true
  ORDER BY created_at DESC
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN;
  END IF;

  INSERT INTO public.profiles(user_id, email, display_name, last_seen_at)
  VALUES (v_user, v_email, coalesce(nullif(v_pre.display_name,''), v_email), now())
  ON CONFLICT (user_id) DO UPDATE
    SET email = excluded.email,
        display_name = coalesce(nullif(public.profiles.display_name,''), excluded.display_name),
        last_seen_at = now();

  FOREACH v_role IN ARRAY coalesce(v_pre.roles, ARRAY[]::text[]) LOOP
    IF v_role <> ALL (ARRAY['Admin','Height equipment manager','Height equipment user','Maintenance manager','Vehicle inspector']) THEN
      RAISE EXCEPTION 'Unsupported preloaded role: %', v_role;
    END IF;

    INSERT INTO public.user_roles(user_id, role, assigned_by)
    SELECT v_user, v_role, v_pre.created_by
    WHERE NOT EXISTS (
      SELECT 1 FROM public.user_roles ur
      WHERE ur.user_id = v_user AND ur.role = v_role
    );
  END LOOP;

  UPDATE public.operations_preloaded_users
  SET claimed_user_id = v_user,
      claimed_at = coalesce(claimed_at, now()),
      status = 'Claimed',
      updated_at = now()
  WHERE id = v_pre.id;
END;
$function$;

CREATE OR REPLACE FUNCTION public.operations_sync_automatic_tasks_v4077()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  maintenance_count integer := 0;
  height_count integer := 0;
BEGIN
  -- Cron and trusted server contexts have no auth.uid(). Authenticated callers
  -- must hold one of the roles that owns automatic task generation.
  IF auth.uid() IS NOT NULL
     AND NOT public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Height equipment manager']) THEN
    RAISE EXCEPTION 'This role cannot synchronise automatic tasks.';
  END IF;

  INSERT INTO public.operations_maintenance_tasks (
    source_type, source_module, source_record_type, source_record_id,
    target_type, target_record_id, target_label, vehicle_id,
    washing_equipment_id, procedure_id, schedule_id, title,
    description, status, priority, due_date, assigned_role,
    automatic_key, created_by
  )
  SELECT
    'Scheduled', 'maintenance', 'maintenance_schedule', schedule.id,
    CASE WHEN schedule.washing_equipment_id IS NOT NULL THEN 'washing_equipment' ELSE 'vehicle' END,
    coalesce(schedule.washing_equipment_id, schedule.vehicle_id),
    coalesce(machinery.asset_identifier, vehicle.rego, 'Maintenance asset'),
    coalesce(machinery.assigned_vehicle_id, schedule.vehicle_id),
    schedule.washing_equipment_id, schedule.procedure_id, schedule.id,
    trim(CASE
      WHEN procedure.category ILIKE 'Planned:%' THEN regexp_replace(procedure.category, '^Planned:\s*', '')
      WHEN procedure.name LIKE 'PM - %' THEN regexp_replace(procedure.name, '^PM - [^-]+ -\s*', '')
      ELSE coalesce(procedure.description, procedure.name, 'Scheduled maintenance')
    END) || ' - ' || coalesce(machinery.asset_identifier, vehicle.rego, 'Asset'),
    coalesce(procedure.description, 'Scheduled maintenance is due.'),
    'Open', 'Medium', schedule.next_due_at::date, 'Maintenance manager',
    'maintenance_schedule:' || schedule.id::text || ':' || schedule.next_due_at::date::text,
    NULL
  FROM public.operations_equipment_maintenance_schedules schedule
  LEFT JOIN public.operations_maintenance_procedures procedure ON procedure.id = schedule.procedure_id
  LEFT JOIN public.operations_washing_equipment machinery ON machinery.id = schedule.washing_equipment_id
  LEFT JOIN public.operations_vehicles vehicle ON vehicle.id = schedule.vehicle_id
  WHERE coalesce(schedule.is_active, true)
    AND schedule.next_due_at IS NOT NULL
    AND schedule.next_due_at::date < current_date
  ON CONFLICT (automatic_key) WHERE automatic_key IS NOT NULL DO NOTHING;

  GET DIAGNOSTICS maintenance_count = ROW_COUNT;

  -- Only the latest effective Height inspection for an item may generate an open
  -- failure task. This prevents historical failures from being recreated after a pass.
  WITH ranked_height AS (
    SELECT i.*,
      row_number() OVER (
        PARTITION BY i.equipment_id
        ORDER BY i.inspection_date DESC, i.created_at DESC NULLS LAST, i.id DESC
      ) AS effective_rank
    FROM public.inspections i
    WHERE i.equipment_id IS NOT NULL
  )
  INSERT INTO public.operations_maintenance_tasks (
    source_type, source_module, source_record_type, source_record_id,
    target_type, target_record_id, target_label, title, description,
    status, priority, due_date, assigned_role, automatic_key, created_by
  )
  SELECT
    'Inspection', 'height_equipment', 'height_inspection', inspection.id,
    'height_equipment', inspection.equipment_id, inspection.serial,
    'Height inspection failed - ' || inspection.serial,
    trim(coalesce(inspection.result, 'Failed inspection') ||
      CASE WHEN nullif(btrim(inspection.notes), '') IS NOT NULL
        THEN E'\n' || btrim(inspection.notes) ELSE '' END),
    'Open', 'Critical', coalesce(inspection.inspection_date, current_date),
    'Height equipment manager', 'height_inspection:' || inspection.id::text, NULL
  FROM ranked_height inspection
  WHERE inspection.effective_rank = 1
    AND inspection.result IN ('Fail - Repair Required','Fail - Remove From Service / Disposal')
  ON CONFLICT (automatic_key) WHERE automatic_key IS NOT NULL DO NOTHING;

  GET DIAGNOSTICS height_count = ROW_COUNT;

  RETURN jsonb_build_object(
    'maintenance_tasks_created', maintenance_count,
    'height_tasks_created', height_count
  );
END;
$function$;

CREATE OR REPLACE FUNCTION public.operations_height_failure_task_v4077()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
  IF new.result IN ('Fail - Repair Required','Fail - Remove From Service / Disposal') THEN
    PERFORM public.operations_sync_automatic_tasks_v4077();

  ELSIF new.result = 'Pass' AND new.equipment_id IS NOT NULL THEN
    -- A backdated pass must not close a task created by a later effective failure.
    IF NOT EXISTS (
      SELECT 1
      FROM public.inspections later
      WHERE later.equipment_id = new.equipment_id
        AND (
          later.inspection_date,
          coalesce(later.created_at, '-infinity'::timestamptz),
          later.id
        ) > (
          new.inspection_date,
          coalesce(new.created_at, '-infinity'::timestamptz),
          new.id
        )
    ) THEN
      UPDATE public.operations_maintenance_tasks task
      SET status = 'Completed',
          completed_at = now(),
          completed_by = auth.uid(),
          completion_notes = coalesce(
            task.completion_notes,
            'Closed automatically after the latest passing Height inspection.'
          )
      WHERE task.source_module = 'height_equipment'
        AND task.source_record_type = 'height_inspection'
        AND task.target_record_id = new.equipment_id
        AND task.automatic_key = 'height_inspection:' || task.source_record_id::text
        AND task.status <> 'Completed'
        AND (
          task.source_record_id = new.id
          OR EXISTS (
            SELECT 1
            FROM public.inspections failed
            WHERE failed.id = task.source_record_id
              AND failed.equipment_id = new.equipment_id
              AND failed.result IN ('Fail - Repair Required','Fail - Remove From Service / Disposal')
              AND (
                failed.inspection_date,
                coalesce(failed.created_at, '-infinity'::timestamptz),
                failed.id
              ) < (
                new.inspection_date,
                coalesce(new.created_at, '-infinity'::timestamptz),
                new.id
              )
          )
        );
    END IF;
  END IF;

  RETURN new;
END;
$function$;

-- Restrict browser-callable RPCs to signed-in users; trigger functions remain owner-only.
REVOKE ALL ON FUNCTION public.claim_preloaded_user_setup() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.claim_preloaded_user_setup() TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.operations_sync_automatic_tasks_v4077() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.operations_sync_automatic_tasks_v4077() TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.operations_height_failure_task_v4077() FROM PUBLIC, anon, authenticated, service_role;

REVOKE ALL ON FUNCTION public.operations_add_maintenance_record_v4053(date,uuid,uuid,jsonb,text,numeric,text,text,text,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.operations_add_maintenance_record_v4053(date,uuid,uuid,jsonb,text,numeric,text,text,text,uuid) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.operations_transfer_machinery_v4049(uuid,uuid,text,text,date,text,text,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.operations_transfer_machinery_v4049(uuid,uuid,text,text,date,text,text,uuid) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.operations_update_task_v4077(uuid,text,text,text,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.operations_update_task_v4077(uuid,text,text,text,uuid) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.spray_wash_has_role(text[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.spray_wash_has_role(text[]) TO authenticated, service_role;
REVOKE ALL ON FUNCTION public.has_any_app_role(text[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_any_app_role(text[]) TO authenticated, service_role;
REVOKE ALL ON FUNCTION public.has_app_role(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_app_role(text) TO authenticated, service_role;

-- Replace the exported live policy set with a single five-role policy model.
DROP POLICY IF EXISTS "app settings admin insert" ON "public"."app_settings";
DROP POLICY IF EXISTS "app settings admin update" ON "public"."app_settings";
DROP POLICY IF EXISTS "app settings select approved" ON "public"."app_settings";
DROP POLICY IF EXISTS "audit logs insert approved users" ON "public"."audit_logs";
DROP POLICY IF EXISTS "audit logs select admin reports" ON "public"."audit_logs";
DROP POLICY IF EXISTS "certificates v34 delete admin" ON "public"."certificates";
DROP POLICY IF EXISTS "certificates v34 insert cert roles" ON "public"."certificates";
DROP POLICY IF EXISTS "certificates v34 select approved" ON "public"."certificates";
DROP POLICY IF EXISTS "certificates v34 update cert roles" ON "public"."certificates";
DROP POLICY IF EXISTS "equipment v34 delete admin" ON "public"."equipment";
DROP POLICY IF EXISTS "equipment v34 insert managers" ON "public"."equipment";
DROP POLICY IF EXISTS "equipment v34 select approved" ON "public"."equipment";
DROP POLICY IF EXISTS "equipment v34 update managers" ON "public"."equipment";
DROP POLICY IF EXISTS "equipment photos v34 delete photo roles" ON "public"."equipment_photos";
DROP POLICY IF EXISTS "equipment photos v34 insert photo roles" ON "public"."equipment_photos";
DROP POLICY IF EXISTS "equipment photos v34 select approved" ON "public"."equipment_photos";
DROP POLICY IF EXISTS "equipment photos v34 update photo roles" ON "public"."equipment_photos";
DROP POLICY IF EXISTS "height inspector quals insert approved" ON "public"."height_inspector_qualifications";
DROP POLICY IF EXISTS "height inspector quals select approved" ON "public"."height_inspector_qualifications";
DROP POLICY IF EXISTS "height inspector quals update managers" ON "public"."height_inspector_qualifications";
DROP POLICY IF EXISTS "inspection photos v34 delete inspectors" ON "public"."inspection_photos";
DROP POLICY IF EXISTS "inspection photos v34 insert inspectors" ON "public"."inspection_photos";
DROP POLICY IF EXISTS "inspection photos v34 select approved" ON "public"."inspection_photos";
DROP POLICY IF EXISTS "inspection photos v34 update inspectors" ON "public"."inspection_photos";
DROP POLICY IF EXISTS "inspections v34 delete admin" ON "public"."inspections";
DROP POLICY IF EXISTS "inspections v34 insert inspectors" ON "public"."inspections";
DROP POLICY IF EXISTS "inspections v34 select approved" ON "public"."inspections";
DROP POLICY IF EXISTS "inspections v34 update inspectors" ON "public"."inspections";
DROP POLICY IF EXISTS "ops items manage managers" ON "public"."operations_checklist_items";
DROP POLICY IF EXISTS "ops items select approved" ON "public"."operations_checklist_items";
DROP POLICY IF EXISTS "ops templates manage managers" ON "public"."operations_checklist_templates";
DROP POLICY IF EXISTS "ops templates select approved" ON "public"."operations_checklist_templates";
DROP POLICY IF EXISTS "ops schedules manage managers" ON "public"."operations_equipment_maintenance_schedules";
DROP POLICY IF EXISTS "ops schedules select approved" ON "public"."operations_equipment_maintenance_schedules";
DROP POLICY IF EXISTS "ops answers insert inspectors" ON "public"."operations_inspection_answers";
DROP POLICY IF EXISTS "ops answers select approved" ON "public"."operations_inspection_answers";
DROP POLICY IF EXISTS "ops photos insert inspectors" ON "public"."operations_inspection_photos";
DROP POLICY IF EXISTS "ops photos select approved" ON "public"."operations_inspection_photos";
DROP POLICY IF EXISTS "ops inspections insert inspectors" ON "public"."operations_inspections";
DROP POLICY IF EXISTS "ops inspections select approved" ON "public"."operations_inspections";
DROP POLICY IF EXISTS "ops inspections update managers" ON "public"."operations_inspections";
DROP POLICY IF EXISTS "Authenticated users can add maintenance log" ON "public"."operations_maintenance_log";
DROP POLICY IF EXISTS "Authenticated users can read maintenance log" ON "public"."operations_maintenance_log";
DROP POLICY IF EXISTS "Maintenance managers can add maintenance log" ON "public"."operations_maintenance_log";
DROP POLICY IF EXISTS "Authenticated users can read maintenance log items" ON "public"."operations_maintenance_log_items";
DROP POLICY IF EXISTS "Maintenance managers can add maintenance log items" ON "public"."operations_maintenance_log_items";
DROP POLICY IF EXISTS "Responsible roles can add task parts" ON "public"."operations_maintenance_parts_used";
DROP POLICY IF EXISTS "Responsible roles can view task parts" ON "public"."operations_maintenance_parts_used";
DROP POLICY IF EXISTS "ops procedure steps manage managers" ON "public"."operations_maintenance_procedure_steps";
DROP POLICY IF EXISTS "ops procedure steps select approved" ON "public"."operations_maintenance_procedure_steps";
DROP POLICY IF EXISTS "ops procedures manage managers" ON "public"."operations_maintenance_procedures";
DROP POLICY IF EXISTS "ops procedures select approved" ON "public"."operations_maintenance_procedures";
DROP POLICY IF EXISTS "ops readings insert approved" ON "public"."operations_maintenance_readings";
DROP POLICY IF EXISTS "ops readings select approved" ON "public"."operations_maintenance_readings";
DROP POLICY IF EXISTS "Responsible roles can add task steps" ON "public"."operations_maintenance_task_steps";
DROP POLICY IF EXISTS "Responsible roles can view task steps" ON "public"."operations_maintenance_task_steps";
DROP POLICY IF EXISTS "Admins can delete shared tasks" ON "public"."operations_maintenance_tasks";
DROP POLICY IF EXISTS "Responsible roles can create shared tasks" ON "public"."operations_maintenance_tasks";
DROP POLICY IF EXISTS "Responsible roles can update shared tasks" ON "public"."operations_maintenance_tasks";
DROP POLICY IF EXISTS "Shared tasks are visible to responsible roles" ON "public"."operations_maintenance_tasks";
DROP POLICY IF EXISTS "ops preloaded users admin manage" ON "public"."operations_preloaded_users";
DROP POLICY IF EXISTS "ops preloaded users self read" ON "public"."operations_preloaded_users";
DROP POLICY IF EXISTS "ops vehicles manage managers" ON "public"."operations_vehicles";
DROP POLICY IF EXISTS "ops vehicles select approved" ON "public"."operations_vehicles";
DROP POLICY IF EXISTS "ops washing equipment manage managers" ON "public"."operations_washing_equipment";
DROP POLICY IF EXISTS "ops washing equipment select approved" ON "public"."operations_washing_equipment";
DROP POLICY IF EXISTS "profiles insert self or admin" ON "public"."profiles";
DROP POLICY IF EXISTS "profiles select self or admin" ON "public"."profiles";
DROP POLICY IF EXISTS "profiles update self or admin" ON "public"."profiles";
DROP POLICY IF EXISTS "user roles delete admin" ON "public"."user_roles";
DROP POLICY IF EXISTS "user roles insert admin" ON "public"."user_roles";
DROP POLICY IF EXISTS "user roles select self or admin" ON "public"."user_roles";
DROP POLICY IF EXISTS "user roles update admin" ON "public"."user_roles";
DROP POLICY IF EXISTS "storage equipment photos v34 delete" ON "storage"."objects";
DROP POLICY IF EXISTS "storage equipment photos v34 insert" ON "storage"."objects";
DROP POLICY IF EXISTS "storage equipment photos v34 select" ON "storage"."objects";
DROP POLICY IF EXISTS "storage equipment photos v34 update" ON "storage"."objects";
DROP POLICY IF EXISTS "storage inspection photos v34 delete" ON "storage"."objects";
DROP POLICY IF EXISTS "storage inspection photos v34 insert" ON "storage"."objects";
DROP POLICY IF EXISTS "storage inspection photos v34 select" ON "storage"."objects";
DROP POLICY IF EXISTS "storage inspection photos v34 update" ON "storage"."objects";

ALTER TABLE "public"."app_settings" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."audit_logs" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."certificates" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."equipment" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."equipment_photos" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."height_inspector_qualifications" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."inspection_photos" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."inspections" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_checklist_items" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_checklist_templates" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_equipment_maintenance_schedules" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_inspection_answers" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_inspection_photos" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_inspections" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_maintenance_log" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_maintenance_log_items" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_maintenance_parts_used" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_maintenance_procedure_steps" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_maintenance_procedures" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_maintenance_readings" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_maintenance_task_steps" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_maintenance_tasks" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_preloaded_users" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_vehicles" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."operations_washing_equipment" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."user_roles" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

CREATE POLICY "phase0 profiles select permitted" ON "public"."profiles"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING ((user_id = auth.uid()) OR public.spray_wash_has_role(ARRAY['Admin']) OR public.spray_wash_has_role(ARRAY['Maintenance manager']));
CREATE POLICY "phase0 profiles insert self or admin" ON "public"."profiles"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK ((user_id = auth.uid()) OR public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 profiles update self or admin" ON "public"."profiles"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING ((user_id = auth.uid()) OR public.spray_wash_has_role(ARRAY['Admin']))
  WITH CHECK ((user_id = auth.uid()) OR public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 user_roles select self or admin" ON "public"."user_roles"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING ((user_id = auth.uid()) OR public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 user_roles insert admin" ON "public"."user_roles"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 user_roles update admin" ON "public"."user_roles"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 user_roles delete admin" ON "public"."user_roles"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 operations_preloaded_users manage admin" ON "public"."operations_preloaded_users"
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 operations_preloaded_users select own invitation" ON "public"."operations_preloaded_users"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (lower(email) = lower(coalesce(auth.jwt() ->> 'email','')));
CREATE POLICY "phase0 app_settings select app roles" ON "public"."app_settings"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager','Height equipment user','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 app_settings insert admin" ON "public"."app_settings"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 app_settings update admin" ON "public"."app_settings"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 app_settings delete admin" ON "public"."app_settings"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 audit_logs insert own app audit" ON "public"."audit_logs"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (actor_user_id = auth.uid() AND public.spray_wash_has_role(ARRAY['Admin','Height equipment manager','Height equipment user','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 audit_logs select admin" ON "public"."audit_logs"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 certificates select height roles" ON "public"."certificates"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager','Height equipment user']));
CREATE POLICY "phase0 equipment select height roles" ON "public"."equipment"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager','Height equipment user']));
CREATE POLICY "phase0 equipment_photos select height roles" ON "public"."equipment_photos"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager','Height equipment user']));
CREATE POLICY "phase0 height_inspector_qualifications select height roles" ON "public"."height_inspector_qualifications"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager','Height equipment user']));
CREATE POLICY "phase0 inspection_photos select height roles" ON "public"."inspection_photos"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager','Height equipment user']));
CREATE POLICY "phase0 inspections select height roles" ON "public"."inspections"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager','Height equipment user']));
CREATE POLICY "phase0 certificates insert height managers" ON "public"."certificates"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 certificates update height managers" ON "public"."certificates"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 equipment insert height managers" ON "public"."equipment"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 equipment update height managers" ON "public"."equipment"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 equipment_photos insert height managers" ON "public"."equipment_photos"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 equipment_photos update height managers" ON "public"."equipment_photos"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 height_inspector_qualifications insert height managers" ON "public"."height_inspector_qualifications"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 height_inspector_qualifications update height managers" ON "public"."height_inspector_qualifications"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 inspection_photos insert height managers" ON "public"."inspection_photos"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 inspection_photos update height managers" ON "public"."inspection_photos"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 inspections insert height managers" ON "public"."inspections"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 inspections update height managers" ON "public"."inspections"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 equipment delete admin" ON "public"."equipment"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 inspections delete admin" ON "public"."inspections"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 certificates delete admin" ON "public"."certificates"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 equipment_photos delete height managers" ON "public"."equipment_photos"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 inspection_photos delete height managers" ON "public"."inspection_photos"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 height_inspector_qualifications delete height managers" ON "public"."height_inspector_qualifications"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 operations_vehicles select operations roles" ON "public"."operations_vehicles"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_vehicles insert maintenance managers" ON "public"."operations_vehicles"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_vehicles update maintenance managers" ON "public"."operations_vehicles"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_vehicles delete maintenance managers" ON "public"."operations_vehicles"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_washing_equipment select operations roles" ON "public"."operations_washing_equipment"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_washing_equipment insert maintenance managers" ON "public"."operations_washing_equipment"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_washing_equipment update maintenance managers" ON "public"."operations_washing_equipment"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_washing_equipment delete maintenance managers" ON "public"."operations_washing_equipment"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_checklist_templates select operations roles" ON "public"."operations_checklist_templates"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_checklist_templates insert maintenance managers" ON "public"."operations_checklist_templates"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_checklist_templates update maintenance managers" ON "public"."operations_checklist_templates"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_checklist_templates delete maintenance managers" ON "public"."operations_checklist_templates"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_checklist_items select operations roles" ON "public"."operations_checklist_items"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_checklist_items insert maintenance managers" ON "public"."operations_checklist_items"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_checklist_items update maintenance managers" ON "public"."operations_checklist_items"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_checklist_items delete maintenance managers" ON "public"."operations_checklist_items"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_equipment_maintenance_schedules select operations roles" ON "public"."operations_equipment_maintenance_schedules"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_equipment_maintenance_schedules insert maintenance managers" ON "public"."operations_equipment_maintenance_schedules"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_equipment_maintenance_schedules update maintenance managers" ON "public"."operations_equipment_maintenance_schedules"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_equipment_maintenance_schedules delete maintenance managers" ON "public"."operations_equipment_maintenance_schedules"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_maintenance_procedures select operations roles" ON "public"."operations_maintenance_procedures"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_maintenance_procedures insert maintenance managers" ON "public"."operations_maintenance_procedures"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_maintenance_procedures update maintenance managers" ON "public"."operations_maintenance_procedures"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_maintenance_procedures delete maintenance managers" ON "public"."operations_maintenance_procedures"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_maintenance_procedure_steps select operations roles" ON "public"."operations_maintenance_procedure_steps"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_maintenance_procedure_steps insert maintenance managers" ON "public"."operations_maintenance_procedure_steps"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_maintenance_procedure_steps update maintenance managers" ON "public"."operations_maintenance_procedure_steps"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_maintenance_procedure_steps delete maintenance managers" ON "public"."operations_maintenance_procedure_steps"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_inspections select operations roles" ON "public"."operations_inspections"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_inspections insert vehicle inspectors" ON "public"."operations_inspections"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Vehicle inspector']));
CREATE POLICY "phase0 operations_inspections update maintenance managers" ON "public"."operations_inspections"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_inspections delete admin" ON "public"."operations_inspections"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 operations_inspection_answers select operations roles" ON "public"."operations_inspection_answers"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_inspection_answers insert vehicle inspectors" ON "public"."operations_inspection_answers"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Vehicle inspector']));
CREATE POLICY "phase0 operations_inspection_answers update maintenance managers" ON "public"."operations_inspection_answers"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_inspection_answers delete admin" ON "public"."operations_inspection_answers"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 operations_inspection_photos select operations roles" ON "public"."operations_inspection_photos"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_inspection_photos insert vehicle inspectors" ON "public"."operations_inspection_photos"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Vehicle inspector']));
CREATE POLICY "phase0 operations_inspection_photos update maintenance managers" ON "public"."operations_inspection_photos"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_inspection_photos delete admin" ON "public"."operations_inspection_photos"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 operations_maintenance_log select operations roles" ON "public"."operations_maintenance_log"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_maintenance_log insert maintenance managers" ON "public"."operations_maintenance_log"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid() AND public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_maintenance_log update maintenance managers" ON "public"."operations_maintenance_log"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_maintenance_log delete admin" ON "public"."operations_maintenance_log"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 operations_maintenance_log_items select operations roles" ON "public"."operations_maintenance_log_items"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_maintenance_log_items insert maintenance managers" ON "public"."operations_maintenance_log_items"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']) AND EXISTS (SELECT 1 FROM public.operations_maintenance_log l WHERE l.id = maintenance_log_id));
CREATE POLICY "phase0 operations_maintenance_log_items update maintenance managers" ON "public"."operations_maintenance_log_items"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_maintenance_log_items delete admin" ON "public"."operations_maintenance_log_items"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 operations_maintenance_readings select operations roles" ON "public"."operations_maintenance_readings"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_maintenance_readings insert operations roles" ON "public"."operations_maintenance_readings"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 operations_maintenance_readings update maintenance managers" ON "public"."operations_maintenance_readings"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']))
  WITH CHECK (public.spray_wash_has_role(ARRAY['Admin','Maintenance manager']));
CREATE POLICY "phase0 operations_maintenance_readings delete admin" ON "public"."operations_maintenance_readings"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 operations_maintenance_tasks select responsible roles" ON "public"."operations_maintenance_tasks"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING ((public.spray_wash_has_role(ARRAY['Admin']) OR (assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (assigned_role = 'Height equipment manager' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR (source_module = 'vehicle_checks' AND created_by = auth.uid() AND public.spray_wash_has_role(ARRAY['Vehicle inspector'])) OR assigned_user_id = auth.uid()));
CREATE POLICY "phase0 operations_maintenance_tasks insert responsible roles" ON "public"."operations_maintenance_tasks"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid() AND (public.spray_wash_has_role(ARRAY['Admin']) OR (assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (assigned_role = 'Height equipment manager' AND source_module = 'height_equipment' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR (source_module = 'vehicle_checks' AND assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Vehicle inspector']))));
CREATE POLICY "phase0 operations_maintenance_tasks update responsible roles" ON "public"."operations_maintenance_tasks"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING ((public.spray_wash_has_role(ARRAY['Admin']) OR (assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (assigned_role = 'Height equipment manager' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR assigned_user_id = auth.uid()))
  WITH CHECK ((public.spray_wash_has_role(ARRAY['Admin']) OR (assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (assigned_role = 'Height equipment manager' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR assigned_user_id = auth.uid()));
CREATE POLICY "phase0 operations_maintenance_tasks delete admin" ON "public"."operations_maintenance_tasks"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (public.spray_wash_has_role(ARRAY['Admin']));
CREATE POLICY "phase0 operations_maintenance_task_steps select visible parent" ON "public"."operations_maintenance_task_steps"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (EXISTS (SELECT 1 FROM public.operations_maintenance_tasks t WHERE t.id = maintenance_task_id));
CREATE POLICY "phase0 operations_maintenance_task_steps insert manageable parent" ON "public"."operations_maintenance_task_steps"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.operations_maintenance_tasks t WHERE t.id = maintenance_task_id AND (public.spray_wash_has_role(ARRAY['Admin']) OR (t.assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (t.assigned_role = 'Height equipment manager' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR t.assigned_user_id = auth.uid())));
CREATE POLICY "phase0 operations_maintenance_task_steps update manageable parent" ON "public"."operations_maintenance_task_steps"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM public.operations_maintenance_tasks t WHERE t.id = maintenance_task_id AND (public.spray_wash_has_role(ARRAY['Admin']) OR (t.assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (t.assigned_role = 'Height equipment manager' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR t.assigned_user_id = auth.uid())))
  WITH CHECK (EXISTS (SELECT 1 FROM public.operations_maintenance_tasks t WHERE t.id = maintenance_task_id AND (public.spray_wash_has_role(ARRAY['Admin']) OR (t.assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (t.assigned_role = 'Height equipment manager' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR t.assigned_user_id = auth.uid())));
CREATE POLICY "phase0 operations_maintenance_task_steps delete manageable parent" ON "public"."operations_maintenance_task_steps"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM public.operations_maintenance_tasks t WHERE t.id = maintenance_task_id AND (public.spray_wash_has_role(ARRAY['Admin']) OR (t.assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (t.assigned_role = 'Height equipment manager' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR t.assigned_user_id = auth.uid())));
CREATE POLICY "phase0 operations_maintenance_parts_used select visible parent" ON "public"."operations_maintenance_parts_used"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (EXISTS (SELECT 1 FROM public.operations_maintenance_tasks t WHERE t.id = maintenance_task_id));
CREATE POLICY "phase0 operations_maintenance_parts_used insert manageable parent" ON "public"."operations_maintenance_parts_used"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.operations_maintenance_tasks t WHERE t.id = maintenance_task_id AND (public.spray_wash_has_role(ARRAY['Admin']) OR (t.assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (t.assigned_role = 'Height equipment manager' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR t.assigned_user_id = auth.uid())));
CREATE POLICY "phase0 operations_maintenance_parts_used update manageable parent" ON "public"."operations_maintenance_parts_used"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM public.operations_maintenance_tasks t WHERE t.id = maintenance_task_id AND (public.spray_wash_has_role(ARRAY['Admin']) OR (t.assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (t.assigned_role = 'Height equipment manager' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR t.assigned_user_id = auth.uid())))
  WITH CHECK (EXISTS (SELECT 1 FROM public.operations_maintenance_tasks t WHERE t.id = maintenance_task_id AND (public.spray_wash_has_role(ARRAY['Admin']) OR (t.assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (t.assigned_role = 'Height equipment manager' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR t.assigned_user_id = auth.uid())));
CREATE POLICY "phase0 operations_maintenance_parts_used delete manageable parent" ON "public"."operations_maintenance_parts_used"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM public.operations_maintenance_tasks t WHERE t.id = maintenance_task_id AND (public.spray_wash_has_role(ARRAY['Admin']) OR (t.assigned_role = 'Maintenance manager' AND public.spray_wash_has_role(ARRAY['Maintenance manager'])) OR (t.assigned_role = 'Height equipment manager' AND public.spray_wash_has_role(ARRAY['Height equipment manager'])) OR t.assigned_user_id = auth.uid())));
CREATE POLICY "phase0 objects select equipment photos" ON "storage"."objects"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (bucket_id = 'equipment-photos' AND public.spray_wash_has_role(ARRAY['Admin','Height equipment manager','Height equipment user']));
CREATE POLICY "phase0 objects insert equipment photos" ON "storage"."objects"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'equipment-photos' AND public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 objects update equipment photos" ON "storage"."objects"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (bucket_id = 'equipment-photos' AND public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']))
  WITH CHECK (bucket_id = 'equipment-photos' AND public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 objects delete equipment photos" ON "storage"."objects"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (bucket_id = 'equipment-photos' AND public.spray_wash_has_role(ARRAY['Admin','Height equipment manager']));
CREATE POLICY "phase0 objects select inspection photos" ON "storage"."objects"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (bucket_id = 'inspection-photos' AND public.spray_wash_has_role(ARRAY['Admin','Height equipment manager','Height equipment user','Maintenance manager','Vehicle inspector']));
CREATE POLICY "phase0 objects insert inspection photos by path" ON "storage"."objects"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'inspection-photos' AND (public.spray_wash_has_role(ARRAY['Admin']) OR (public.spray_wash_has_role(ARRAY['Height equipment manager']) AND split_part(name,'/',1) NOT IN ('operations-inspections','operations-assets','app-branding')) OR (public.spray_wash_has_role(ARRAY['Maintenance manager']) AND split_part(name,'/',1) = 'operations-assets') OR (public.spray_wash_has_role(ARRAY['Vehicle inspector']) AND split_part(name,'/',1) = 'operations-inspections')));
CREATE POLICY "phase0 objects update inspection photos by path" ON "storage"."objects"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (bucket_id = 'inspection-photos' AND (public.spray_wash_has_role(ARRAY['Admin']) OR (public.spray_wash_has_role(ARRAY['Height equipment manager']) AND split_part(name,'/',1) NOT IN ('operations-inspections','operations-assets','app-branding')) OR (public.spray_wash_has_role(ARRAY['Maintenance manager']) AND split_part(name,'/',1) = 'operations-assets') OR (public.spray_wash_has_role(ARRAY['Vehicle inspector']) AND split_part(name,'/',1) = 'operations-inspections')))
  WITH CHECK (bucket_id = 'inspection-photos' AND (public.spray_wash_has_role(ARRAY['Admin']) OR (public.spray_wash_has_role(ARRAY['Height equipment manager']) AND split_part(name,'/',1) NOT IN ('operations-inspections','operations-assets','app-branding')) OR (public.spray_wash_has_role(ARRAY['Maintenance manager']) AND split_part(name,'/',1) = 'operations-assets') OR (public.spray_wash_has_role(ARRAY['Vehicle inspector']) AND split_part(name,'/',1) = 'operations-inspections')));
CREATE POLICY "phase0 objects delete inspection photos by path" ON "storage"."objects"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (bucket_id = 'inspection-photos' AND (public.spray_wash_has_role(ARRAY['Admin']) OR (public.spray_wash_has_role(ARRAY['Height equipment manager']) AND split_part(name,'/',1) NOT IN ('operations-inspections','operations-assets','app-branding')) OR (public.spray_wash_has_role(ARRAY['Maintenance manager']) AND split_part(name,'/',1) = 'operations-assets') OR (public.spray_wash_has_role(ARRAY['Vehicle inspector']) AND split_part(name,'/',1) = 'operations-inspections')));

COMMENT ON FUNCTION public.operations_sync_automatic_tasks_v4077() IS
  'Phase 0: role-restricted automatic task sync; Height tasks only for latest effective failure.';
COMMENT ON FUNCTION public.operations_height_failure_task_v4077() IS
  'Phase 0: latest-pass-only closure of related automatic Height failure tasks.';

COMMIT;
