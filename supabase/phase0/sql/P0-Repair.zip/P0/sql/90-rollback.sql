-- Spray & Wash Phase 0 full rollback to the 30 July 2026 live catalogue
-- Use only if the Phase 0 migration must be reversed before new current-role users
-- or Waiting on Someone task rows have been added.

BEGIN;
SET LOCAL lock_timeout = '10s';
SET LOCAL statement_timeout = '5min';

DO $$
DECLARE v_roles text; v_waiting integer; v_preloaded text;
BEGIN
  SELECT string_agg(DISTINCT role, ', ' ORDER BY role) INTO v_roles
  FROM public.user_roles
  WHERE role NOT IN ('Admin','Inspector','Equipment Manager','Certificate Approver','Office / Reports','Viewer');
  SELECT count(*) INTO v_waiting FROM public.operations_maintenance_tasks WHERE status='Waiting on Someone';
  SELECT string_agg(DISTINCT r, ', ' ORDER BY r) INTO v_preloaded
  FROM public.operations_preloaded_users u
  CROSS JOIN LATERAL unnest(coalesce(u.roles,ARRAY[]::text[])) r
  WHERE r NOT IN ('Admin','Inspector','Equipment Manager','Certificate Approver','Office / Reports','Viewer');
  IF v_roles IS NOT NULL OR v_waiting > 0 OR v_preloaded IS NOT NULL THEN
    RAISE EXCEPTION 'Full rollback is unsafe. New roles=%; Waiting on Someone rows=%; preloaded roles=%',
      coalesce(v_roles,'none'), v_waiting, coalesce(v_preloaded,'none');
  END IF;
END $$;

DROP POLICY IF EXISTS "phase0 app_settings delete admin" ON "public"."app_settings";
DROP POLICY IF EXISTS "phase0 app_settings insert admin" ON "public"."app_settings";
DROP POLICY IF EXISTS "phase0 app_settings select app roles" ON "public"."app_settings";
DROP POLICY IF EXISTS "phase0 app_settings update admin" ON "public"."app_settings";
DROP POLICY IF EXISTS "phase0 audit_logs insert own app audit" ON "public"."audit_logs";
DROP POLICY IF EXISTS "phase0 audit_logs select admin" ON "public"."audit_logs";
DROP POLICY IF EXISTS "phase0 certificates delete admin" ON "public"."certificates";
DROP POLICY IF EXISTS "phase0 certificates insert height managers" ON "public"."certificates";
DROP POLICY IF EXISTS "phase0 certificates select height roles" ON "public"."certificates";
DROP POLICY IF EXISTS "phase0 certificates update height managers" ON "public"."certificates";
DROP POLICY IF EXISTS "phase0 equipment delete admin" ON "public"."equipment";
DROP POLICY IF EXISTS "phase0 equipment insert height managers" ON "public"."equipment";
DROP POLICY IF EXISTS "phase0 equipment select height roles" ON "public"."equipment";
DROP POLICY IF EXISTS "phase0 equipment update height managers" ON "public"."equipment";
DROP POLICY IF EXISTS "phase0 equipment_photos delete height managers" ON "public"."equipment_photos";
DROP POLICY IF EXISTS "phase0 equipment_photos insert height managers" ON "public"."equipment_photos";
DROP POLICY IF EXISTS "phase0 equipment_photos select height roles" ON "public"."equipment_photos";
DROP POLICY IF EXISTS "phase0 equipment_photos update height managers" ON "public"."equipment_photos";
DROP POLICY IF EXISTS "phase0 height_inspector_qualifications delete height managers" ON "public"."height_inspector_qualifications";
DROP POLICY IF EXISTS "phase0 height_inspector_qualifications insert height managers" ON "public"."height_inspector_qualifications";
DROP POLICY IF EXISTS "phase0 height_inspector_qualifications select height roles" ON "public"."height_inspector_qualifications";
DROP POLICY IF EXISTS "phase0 height_inspector_qualifications update height managers" ON "public"."height_inspector_qualifications";
DROP POLICY IF EXISTS "phase0 inspection_photos delete height managers" ON "public"."inspection_photos";
DROP POLICY IF EXISTS "phase0 inspection_photos insert height managers" ON "public"."inspection_photos";
DROP POLICY IF EXISTS "phase0 inspection_photos select height roles" ON "public"."inspection_photos";
DROP POLICY IF EXISTS "phase0 inspection_photos update height managers" ON "public"."inspection_photos";
DROP POLICY IF EXISTS "phase0 inspections delete admin" ON "public"."inspections";
DROP POLICY IF EXISTS "phase0 inspections insert height managers" ON "public"."inspections";
DROP POLICY IF EXISTS "phase0 inspections select height roles" ON "public"."inspections";
DROP POLICY IF EXISTS "phase0 inspections update height managers" ON "public"."inspections";
DROP POLICY IF EXISTS "phase0 operations_checklist_items delete maintenance managers" ON "public"."operations_checklist_items";
DROP POLICY IF EXISTS "phase0 operations_checklist_items insert maintenance managers" ON "public"."operations_checklist_items";
DROP POLICY IF EXISTS "phase0 operations_checklist_items select operations roles" ON "public"."operations_checklist_items";
DROP POLICY IF EXISTS "phase0 operations_checklist_items update maintenance managers" ON "public"."operations_checklist_items";
DROP POLICY IF EXISTS "phase0 operations_checklist_templates delete maintenance managers" ON "public"."operations_checklist_templates";
DROP POLICY IF EXISTS "phase0 operations_checklist_templates insert maintenance managers" ON "public"."operations_checklist_templates";
DROP POLICY IF EXISTS "phase0 operations_checklist_templates select operations roles" ON "public"."operations_checklist_templates";
DROP POLICY IF EXISTS "phase0 operations_checklist_templates update maintenance managers" ON "public"."operations_checklist_templates";
DROP POLICY IF EXISTS "phase0 operations_equipment_maintenance_schedules delete maintenance managers" ON "public"."operations_equipment_maintenance_schedules";
DROP POLICY IF EXISTS "phase0 operations_equipment_maintenance_schedules insert maintenance managers" ON "public"."operations_equipment_maintenance_schedules";
DROP POLICY IF EXISTS "phase0 operations_equipment_maintenance_schedules select operations roles" ON "public"."operations_equipment_maintenance_schedules";
DROP POLICY IF EXISTS "phase0 operations_equipment_maintenance_schedules update maintenance managers" ON "public"."operations_equipment_maintenance_schedules";
DROP POLICY IF EXISTS "phase0 operations_inspection_answers delete admin" ON "public"."operations_inspection_answers";
DROP POLICY IF EXISTS "phase0 operations_inspection_answers insert vehicle inspectors" ON "public"."operations_inspection_answers";
DROP POLICY IF EXISTS "phase0 operations_inspection_answers select operations roles" ON "public"."operations_inspection_answers";
DROP POLICY IF EXISTS "phase0 operations_inspection_answers update maintenance managers" ON "public"."operations_inspection_answers";
DROP POLICY IF EXISTS "phase0 operations_inspection_photos delete admin" ON "public"."operations_inspection_photos";
DROP POLICY IF EXISTS "phase0 operations_inspection_photos insert vehicle inspectors" ON "public"."operations_inspection_photos";
DROP POLICY IF EXISTS "phase0 operations_inspection_photos select operations roles" ON "public"."operations_inspection_photos";
DROP POLICY IF EXISTS "phase0 operations_inspection_photos update maintenance managers" ON "public"."operations_inspection_photos";
DROP POLICY IF EXISTS "phase0 operations_inspections delete admin" ON "public"."operations_inspections";
DROP POLICY IF EXISTS "phase0 operations_inspections insert vehicle inspectors" ON "public"."operations_inspections";
DROP POLICY IF EXISTS "phase0 operations_inspections select operations roles" ON "public"."operations_inspections";
DROP POLICY IF EXISTS "phase0 operations_inspections update maintenance managers" ON "public"."operations_inspections";
DROP POLICY IF EXISTS "phase0 operations_maintenance_log delete admin" ON "public"."operations_maintenance_log";
DROP POLICY IF EXISTS "phase0 operations_maintenance_log insert maintenance managers" ON "public"."operations_maintenance_log";
DROP POLICY IF EXISTS "phase0 operations_maintenance_log select operations roles" ON "public"."operations_maintenance_log";
DROP POLICY IF EXISTS "phase0 operations_maintenance_log update maintenance managers" ON "public"."operations_maintenance_log";
DROP POLICY IF EXISTS "phase0 operations_maintenance_log_items delete admin" ON "public"."operations_maintenance_log_items";
DROP POLICY IF EXISTS "phase0 operations_maintenance_log_items insert maintenance managers" ON "public"."operations_maintenance_log_items";
DROP POLICY IF EXISTS "phase0 operations_maintenance_log_items select operations roles" ON "public"."operations_maintenance_log_items";
DROP POLICY IF EXISTS "phase0 operations_maintenance_log_items update maintenance managers" ON "public"."operations_maintenance_log_items";
DROP POLICY IF EXISTS "phase0 operations_maintenance_parts_used delete manageable parent" ON "public"."operations_maintenance_parts_used";
DROP POLICY IF EXISTS "phase0 operations_maintenance_parts_used insert manageable parent" ON "public"."operations_maintenance_parts_used";
DROP POLICY IF EXISTS "phase0 operations_maintenance_parts_used select visible parent" ON "public"."operations_maintenance_parts_used";
DROP POLICY IF EXISTS "phase0 operations_maintenance_parts_used update manageable parent" ON "public"."operations_maintenance_parts_used";
DROP POLICY IF EXISTS "phase0 operations_maintenance_procedure_steps delete maintenance managers" ON "public"."operations_maintenance_procedure_steps";
DROP POLICY IF EXISTS "phase0 operations_maintenance_procedure_steps insert maintenance managers" ON "public"."operations_maintenance_procedure_steps";
DROP POLICY IF EXISTS "phase0 operations_maintenance_procedure_steps select operations roles" ON "public"."operations_maintenance_procedure_steps";
DROP POLICY IF EXISTS "phase0 operations_maintenance_procedure_steps update maintenance managers" ON "public"."operations_maintenance_procedure_steps";
DROP POLICY IF EXISTS "phase0 operations_maintenance_procedures delete maintenance managers" ON "public"."operations_maintenance_procedures";
DROP POLICY IF EXISTS "phase0 operations_maintenance_procedures insert maintenance managers" ON "public"."operations_maintenance_procedures";
DROP POLICY IF EXISTS "phase0 operations_maintenance_procedures select operations roles" ON "public"."operations_maintenance_procedures";
DROP POLICY IF EXISTS "phase0 operations_maintenance_procedures update maintenance managers" ON "public"."operations_maintenance_procedures";
DROP POLICY IF EXISTS "phase0 operations_maintenance_readings delete admin" ON "public"."operations_maintenance_readings";
DROP POLICY IF EXISTS "phase0 operations_maintenance_readings insert operations roles" ON "public"."operations_maintenance_readings";
DROP POLICY IF EXISTS "phase0 operations_maintenance_readings select operations roles" ON "public"."operations_maintenance_readings";
DROP POLICY IF EXISTS "phase0 operations_maintenance_readings update maintenance managers" ON "public"."operations_maintenance_readings";
DROP POLICY IF EXISTS "phase0 operations_maintenance_task_steps delete manageable parent" ON "public"."operations_maintenance_task_steps";
DROP POLICY IF EXISTS "phase0 operations_maintenance_task_steps insert manageable parent" ON "public"."operations_maintenance_task_steps";
DROP POLICY IF EXISTS "phase0 operations_maintenance_task_steps select visible parent" ON "public"."operations_maintenance_task_steps";
DROP POLICY IF EXISTS "phase0 operations_maintenance_task_steps update manageable parent" ON "public"."operations_maintenance_task_steps";
DROP POLICY IF EXISTS "phase0 operations_maintenance_tasks delete admin" ON "public"."operations_maintenance_tasks";
DROP POLICY IF EXISTS "phase0 operations_maintenance_tasks insert responsible roles" ON "public"."operations_maintenance_tasks";
DROP POLICY IF EXISTS "phase0 operations_maintenance_tasks select responsible roles" ON "public"."operations_maintenance_tasks";
DROP POLICY IF EXISTS "phase0 operations_maintenance_tasks update responsible roles" ON "public"."operations_maintenance_tasks";
DROP POLICY IF EXISTS "phase0 operations_preloaded_users manage admin" ON "public"."operations_preloaded_users";
DROP POLICY IF EXISTS "phase0 operations_preloaded_users select own invitation" ON "public"."operations_preloaded_users";
DROP POLICY IF EXISTS "phase0 operations_vehicles delete maintenance managers" ON "public"."operations_vehicles";
DROP POLICY IF EXISTS "phase0 operations_vehicles insert maintenance managers" ON "public"."operations_vehicles";
DROP POLICY IF EXISTS "phase0 operations_vehicles select operations roles" ON "public"."operations_vehicles";
DROP POLICY IF EXISTS "phase0 operations_vehicles update maintenance managers" ON "public"."operations_vehicles";
DROP POLICY IF EXISTS "phase0 operations_washing_equipment delete maintenance managers" ON "public"."operations_washing_equipment";
DROP POLICY IF EXISTS "phase0 operations_washing_equipment insert maintenance managers" ON "public"."operations_washing_equipment";
DROP POLICY IF EXISTS "phase0 operations_washing_equipment select operations roles" ON "public"."operations_washing_equipment";
DROP POLICY IF EXISTS "phase0 operations_washing_equipment update maintenance managers" ON "public"."operations_washing_equipment";
DROP POLICY IF EXISTS "phase0 profiles insert self or admin" ON "public"."profiles";
DROP POLICY IF EXISTS "phase0 profiles select permitted" ON "public"."profiles";
DROP POLICY IF EXISTS "phase0 profiles update self or admin" ON "public"."profiles";
DROP POLICY IF EXISTS "phase0 user_roles delete admin" ON "public"."user_roles";
DROP POLICY IF EXISTS "phase0 user_roles insert admin" ON "public"."user_roles";
DROP POLICY IF EXISTS "phase0 user_roles select self or admin" ON "public"."user_roles";
DROP POLICY IF EXISTS "phase0 user_roles update admin" ON "public"."user_roles";
DROP POLICY IF EXISTS "phase0 objects delete equipment photos" ON "storage"."objects";
DROP POLICY IF EXISTS "phase0 objects delete inspection photos by path" ON "storage"."objects";
DROP POLICY IF EXISTS "phase0 objects insert equipment photos" ON "storage"."objects";
DROP POLICY IF EXISTS "phase0 objects insert inspection photos by path" ON "storage"."objects";
DROP POLICY IF EXISTS "phase0 objects select equipment photos" ON "storage"."objects";
DROP POLICY IF EXISTS "phase0 objects select inspection photos" ON "storage"."objects";
DROP POLICY IF EXISTS "phase0 objects update equipment photos" ON "storage"."objects";
DROP POLICY IF EXISTS "phase0 objects update inspection photos by path" ON "storage"."objects";

CREATE POLICY "app settings admin insert" ON "public"."app_settings"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text]));
CREATE POLICY "app settings admin update" ON "public"."app_settings"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text]));
CREATE POLICY "app settings select approved" ON "public"."app_settings"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Certificate Approver'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "audit logs insert approved users" ON "public"."audit_logs"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (((actor_user_id = auth.uid()) AND has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Certificate Approver'::text, 'Office / Reports'::text])));
CREATE POLICY "audit logs select admin reports" ON "public"."audit_logs"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Office / Reports'::text, 'Certificate Approver'::text]));
CREATE POLICY "certificates v34 delete admin" ON "public"."certificates"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text]));
CREATE POLICY "certificates v34 insert cert roles" ON "public"."certificates"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Certificate Approver'::text, 'Office / Reports'::text]));
CREATE POLICY "certificates v34 select approved" ON "public"."certificates"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Certificate Approver'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "certificates v34 update cert roles" ON "public"."certificates"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Certificate Approver'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Certificate Approver'::text]));
CREATE POLICY "equipment v34 delete admin" ON "public"."equipment"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text]));
CREATE POLICY "equipment v34 insert managers" ON "public"."equipment"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]));
CREATE POLICY "equipment v34 select approved" ON "public"."equipment"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Certificate Approver'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "equipment v34 update managers" ON "public"."equipment"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]));
CREATE POLICY "equipment photos v34 delete photo roles" ON "public"."equipment_photos"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text]));
CREATE POLICY "equipment photos v34 insert photo roles" ON "public"."equipment_photos"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text]));
CREATE POLICY "equipment photos v34 select approved" ON "public"."equipment_photos"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Certificate Approver'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "equipment photos v34 update photo roles" ON "public"."equipment_photos"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text]));
CREATE POLICY "height inspector quals insert approved" ON "public"."height_inspector_qualifications"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Certificate Approver'::text]));
CREATE POLICY "height inspector quals select approved" ON "public"."height_inspector_qualifications"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Certificate Approver'::text, 'Viewer'::text]));
CREATE POLICY "height inspector quals update managers" ON "public"."height_inspector_qualifications"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]));
CREATE POLICY "inspection photos v34 delete inspectors" ON "public"."inspection_photos"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text]));
CREATE POLICY "inspection photos v34 insert inspectors" ON "public"."inspection_photos"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text]));
CREATE POLICY "inspection photos v34 select approved" ON "public"."inspection_photos"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Certificate Approver'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "inspection photos v34 update inspectors" ON "public"."inspection_photos"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text]));
CREATE POLICY "inspections v34 delete admin" ON "public"."inspections"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text]));
CREATE POLICY "inspections v34 insert inspectors" ON "public"."inspections"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text]));
CREATE POLICY "inspections v34 select approved" ON "public"."inspections"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Certificate Approver'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "inspections v34 update inspectors" ON "public"."inspections"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text]));
CREATE POLICY "ops items manage managers" ON "public"."operations_checklist_items"
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]));
CREATE POLICY "ops items select approved" ON "public"."operations_checklist_items"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "ops templates manage managers" ON "public"."operations_checklist_templates"
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]));
CREATE POLICY "ops templates select approved" ON "public"."operations_checklist_templates"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "ops schedules manage managers" ON "public"."operations_equipment_maintenance_schedules"
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]));
CREATE POLICY "ops schedules select approved" ON "public"."operations_equipment_maintenance_schedules"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "ops answers insert inspectors" ON "public"."operations_inspection_answers"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text]));
CREATE POLICY "ops answers select approved" ON "public"."operations_inspection_answers"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "ops photos insert inspectors" ON "public"."operations_inspection_photos"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text]));
CREATE POLICY "ops photos select approved" ON "public"."operations_inspection_photos"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "ops inspections insert inspectors" ON "public"."operations_inspections"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text]));
CREATE POLICY "ops inspections select approved" ON "public"."operations_inspections"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "ops inspections update managers" ON "public"."operations_inspections"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]));
CREATE POLICY "Authenticated users can add maintenance log" ON "public"."operations_maintenance_log"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (((created_by = auth.uid()) AND (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = ANY (ARRAY['Admin'::text, 'Equipment Manager'::text])))))));
CREATE POLICY "Authenticated users can read maintenance log" ON "public"."operations_maintenance_log"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (true);
CREATE POLICY "Maintenance managers can add maintenance log" ON "public"."operations_maintenance_log"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (((created_by = auth.uid()) AND spray_wash_has_role(ARRAY['Admin'::text, 'Maintenance manager'::text])));
CREATE POLICY "Authenticated users can read maintenance log items" ON "public"."operations_maintenance_log_items"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (true);
CREATE POLICY "Maintenance managers can add maintenance log items" ON "public"."operations_maintenance_log_items"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (((EXISTS ( SELECT 1
   FROM operations_maintenance_log maintenance_log
  WHERE ((maintenance_log.id = operations_maintenance_log_items.maintenance_log_id) AND (maintenance_log.created_by = auth.uid())))) AND spray_wash_has_role(ARRAY['Admin'::text, 'Maintenance manager'::text])));
CREATE POLICY "Responsible roles can add task parts" ON "public"."operations_maintenance_parts_used"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK ((EXISTS ( SELECT 1
   FROM operations_maintenance_tasks task
  WHERE ((task.id = operations_maintenance_parts_used.maintenance_task_id) AND (spray_wash_has_role(ARRAY['Admin'::text]) OR ((task.assigned_role = 'Maintenance manager'::text) AND spray_wash_has_role(ARRAY['Maintenance manager'::text])) OR ((task.assigned_role = 'Height equipment manager'::text) AND spray_wash_has_role(ARRAY['Height equipment manager'::text])) OR (task.assigned_user_id = auth.uid()))))));
CREATE POLICY "Responsible roles can view task parts" ON "public"."operations_maintenance_parts_used"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING ((EXISTS ( SELECT 1
   FROM operations_maintenance_tasks task
  WHERE (task.id = operations_maintenance_parts_used.maintenance_task_id))));
CREATE POLICY "ops procedure steps manage managers" ON "public"."operations_maintenance_procedure_steps"
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]));
CREATE POLICY "ops procedure steps select approved" ON "public"."operations_maintenance_procedure_steps"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "ops procedures manage managers" ON "public"."operations_maintenance_procedures"
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]));
CREATE POLICY "ops procedures select approved" ON "public"."operations_maintenance_procedures"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "ops readings insert approved" ON "public"."operations_maintenance_readings"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text]));
CREATE POLICY "ops readings select approved" ON "public"."operations_maintenance_readings"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "Responsible roles can add task steps" ON "public"."operations_maintenance_task_steps"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK ((EXISTS ( SELECT 1
   FROM operations_maintenance_tasks task
  WHERE ((task.id = operations_maintenance_task_steps.maintenance_task_id) AND (spray_wash_has_role(ARRAY['Admin'::text]) OR ((task.assigned_role = 'Maintenance manager'::text) AND spray_wash_has_role(ARRAY['Maintenance manager'::text])) OR ((task.assigned_role = 'Height equipment manager'::text) AND spray_wash_has_role(ARRAY['Height equipment manager'::text])) OR (task.assigned_user_id = auth.uid()))))));
CREATE POLICY "Responsible roles can view task steps" ON "public"."operations_maintenance_task_steps"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING ((EXISTS ( SELECT 1
   FROM operations_maintenance_tasks task
  WHERE (task.id = operations_maintenance_task_steps.maintenance_task_id))));
CREATE POLICY "Admins can delete shared tasks" ON "public"."operations_maintenance_tasks"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (spray_wash_has_role(ARRAY['Admin'::text]));
CREATE POLICY "Responsible roles can create shared tasks" ON "public"."operations_maintenance_tasks"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (((created_by = auth.uid()) AND (spray_wash_has_role(ARRAY['Admin'::text]) OR ((assigned_role = 'Maintenance manager'::text) AND spray_wash_has_role(ARRAY['Maintenance manager'::text])) OR ((assigned_role = 'Height equipment manager'::text) AND (source_module = 'height_equipment'::text) AND spray_wash_has_role(ARRAY['Height equipment manager'::text])) OR ((source_module = 'vehicle_checks'::text) AND (assigned_role = 'Maintenance manager'::text) AND spray_wash_has_role(ARRAY['Vehicle inspector'::text])))));
CREATE POLICY "Responsible roles can update shared tasks" ON "public"."operations_maintenance_tasks"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING ((spray_wash_has_role(ARRAY['Admin'::text]) OR ((assigned_role = 'Maintenance manager'::text) AND spray_wash_has_role(ARRAY['Maintenance manager'::text])) OR ((assigned_role = 'Height equipment manager'::text) AND spray_wash_has_role(ARRAY['Height equipment manager'::text])) OR (assigned_user_id = auth.uid())))
  WITH CHECK ((spray_wash_has_role(ARRAY['Admin'::text]) OR ((assigned_role = 'Maintenance manager'::text) AND spray_wash_has_role(ARRAY['Maintenance manager'::text])) OR ((assigned_role = 'Height equipment manager'::text) AND spray_wash_has_role(ARRAY['Height equipment manager'::text])) OR (assigned_user_id = auth.uid())));
CREATE POLICY "Shared tasks are visible to responsible roles" ON "public"."operations_maintenance_tasks"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING ((spray_wash_has_role(ARRAY['Admin'::text]) OR ((assigned_role = 'Maintenance manager'::text) AND spray_wash_has_role(ARRAY['Maintenance manager'::text])) OR ((assigned_role = 'Height equipment manager'::text) AND spray_wash_has_role(ARRAY['Height equipment manager'::text])) OR ((source_module = 'vehicle_checks'::text) AND (created_by = auth.uid()) AND spray_wash_has_role(ARRAY['Vehicle inspector'::text])) OR (assigned_user_id = auth.uid())));
CREATE POLICY "ops preloaded users admin manage" ON "public"."operations_preloaded_users"
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text]));
CREATE POLICY "ops preloaded users self read" ON "public"."operations_preloaded_users"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING ((lower(email) = lower(COALESCE((auth.jwt() ->> 'email'::text), ''::text))));
CREATE POLICY "ops vehicles manage managers" ON "public"."operations_vehicles"
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]));
CREATE POLICY "ops vehicles select approved" ON "public"."operations_vehicles"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "ops washing equipment manage managers" ON "public"."operations_washing_equipment"
  AS PERMISSIVE
  FOR ALL
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]))
  WITH CHECK (has_any_app_role(ARRAY['Admin'::text, 'Equipment Manager'::text]));
CREATE POLICY "ops washing equipment select approved" ON "public"."operations_washing_equipment"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Office / Reports'::text, 'Viewer'::text]));
CREATE POLICY "profiles insert self or admin" ON "public"."profiles"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (((user_id = auth.uid()) OR has_app_role('Admin'::text)));
CREATE POLICY "profiles select self or admin" ON "public"."profiles"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (((user_id = auth.uid()) OR has_app_role('Admin'::text)));
CREATE POLICY "profiles update self or admin" ON "public"."profiles"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (((user_id = auth.uid()) OR has_app_role('Admin'::text)))
  WITH CHECK (((user_id = auth.uid()) OR has_app_role('Admin'::text)));
CREATE POLICY "user roles delete admin" ON "public"."user_roles"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (has_app_role('Admin'::text));
CREATE POLICY "user roles insert admin" ON "public"."user_roles"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (has_app_role('Admin'::text));
CREATE POLICY "user roles select self or admin" ON "public"."user_roles"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (((user_id = auth.uid()) OR has_app_role('Admin'::text)));
CREATE POLICY "user roles update admin" ON "public"."user_roles"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (has_app_role('Admin'::text))
  WITH CHECK (has_app_role('Admin'::text));
CREATE POLICY "storage equipment photos v34 delete" ON "storage"."objects"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (((bucket_id = 'equipment-photos'::text) AND has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text])));
CREATE POLICY "storage equipment photos v34 insert" ON "storage"."objects"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (((bucket_id = 'equipment-photos'::text) AND has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text])));
CREATE POLICY "storage equipment photos v34 select" ON "storage"."objects"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (((bucket_id = 'equipment-photos'::text) AND has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Certificate Approver'::text, 'Office / Reports'::text, 'Viewer'::text])));
CREATE POLICY "storage equipment photos v34 update" ON "storage"."objects"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (((bucket_id = 'equipment-photos'::text) AND has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text])))
  WITH CHECK (((bucket_id = 'equipment-photos'::text) AND has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text])));
CREATE POLICY "storage inspection photos v34 delete" ON "storage"."objects"
  AS PERMISSIVE
  FOR DELETE
  TO authenticated
  USING (((bucket_id = 'inspection-photos'::text) AND has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text])));
CREATE POLICY "storage inspection photos v34 insert" ON "storage"."objects"
  AS PERMISSIVE
  FOR INSERT
  TO authenticated
  WITH CHECK (((bucket_id = 'inspection-photos'::text) AND has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text])));
CREATE POLICY "storage inspection photos v34 select" ON "storage"."objects"
  AS PERMISSIVE
  FOR SELECT
  TO authenticated
  USING (((bucket_id = 'inspection-photos'::text) AND has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text, 'Equipment Manager'::text, 'Certificate Approver'::text, 'Office / Reports'::text, 'Viewer'::text])));
CREATE POLICY "storage inspection photos v34 update" ON "storage"."objects"
  AS PERMISSIVE
  FOR UPDATE
  TO authenticated
  USING (((bucket_id = 'inspection-photos'::text) AND has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text])))
  WITH CHECK (((bucket_id = 'inspection-photos'::text) AND has_any_app_role(ARRAY['Admin'::text, 'Inspector'::text])));

ALTER TABLE public.user_roles DROP CONSTRAINT IF EXISTS user_roles_role_check;
ALTER TABLE public.user_roles ADD CONSTRAINT user_roles_role_check
  CHECK (role = ANY (ARRAY['Admin','Inspector','Equipment Manager','Certificate Approver','Office / Reports','Viewer']::text[]));

ALTER TABLE public.operations_preloaded_users DROP CONSTRAINT IF EXISTS operations_preloaded_users_roles_check;
ALTER TABLE public.operations_preloaded_users ALTER COLUMN roles SET DEFAULT ARRAY['Viewer']::text[];

ALTER TABLE public.operations_maintenance_tasks DROP CONSTRAINT IF EXISTS operations_maintenance_tasks_status_check;
ALTER TABLE public.operations_maintenance_tasks ADD CONSTRAINT operations_maintenance_tasks_status_check
  CHECK (status = ANY (ARRAY['Open','In Progress','Waiting on Parts','Completed','Deferred']::text[]));

CREATE OR REPLACE FUNCTION public.claim_preloaded_user_setup()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_user uuid := auth.uid();
  v_email text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_pre public.operations_preloaded_users%rowtype;
  v_role text;
begin
  if v_user is null or v_email = '' then
    return;
  end if;

  select * into v_pre
  from public.operations_preloaded_users
  where lower(email) = v_email
    and active = true
  order by created_at desc
  limit 1;

  if not found then
    return;
  end if;

  insert into public.profiles(user_id, email, display_name, last_seen_at)
  values (v_user, v_email, coalesce(nullif(v_pre.display_name,''), v_email), now())
  on conflict (user_id) do update
    set email = excluded.email,
        display_name = coalesce(nullif(public.profiles.display_name,''), excluded.display_name),
        last_seen_at = now();

  foreach v_role in array coalesce(v_pre.roles, array['Viewer']::text[]) loop
    if v_role = any(array['Admin','Inspector','Equipment Manager','Certificate Approver','Office / Reports','Viewer']::text[]) then
      insert into public.user_roles(user_id, role, assigned_by)
      select v_user, v_role, v_pre.created_by
      where not exists (
        select 1 from public.user_roles ur
        where ur.user_id = v_user and ur.role = v_role
      );
    end if;
  end loop;

  update public.operations_preloaded_users
  set claimed_user_id = v_user,
      claimed_at = coalesce(claimed_at, now()),
      status = 'Claimed',
      updated_at = now()
  where id = v_pre.id;
end;
$function$
;

CREATE OR REPLACE FUNCTION public.operations_sync_automatic_tasks_v4077()
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  maintenance_count integer := 0;
  height_count integer := 0;
begin
  insert into public.operations_maintenance_tasks (
    source_type,
    source_module,
    source_record_type,
    source_record_id,
    target_type,
    target_record_id,
    target_label,
    vehicle_id,
    washing_equipment_id,
    procedure_id,
    schedule_id,
    title,
    description,
    status,
    priority,
    due_date,
    assigned_role,
    automatic_key,
    created_by
  )
  select
    'Scheduled',
    'maintenance',
    'maintenance_schedule',
    schedule.id,
    case
      when schedule.washing_equipment_id is not null then 'washing_equipment'
      else 'vehicle'
    end,
    coalesce(schedule.washing_equipment_id, schedule.vehicle_id),
    coalesce(
      machinery.asset_identifier,
      vehicle.rego,
      'Maintenance asset'
    ),
    coalesce(machinery.assigned_vehicle_id, schedule.vehicle_id),
    schedule.washing_equipment_id,
    schedule.procedure_id,
    schedule.id,
    trim(
      case
        when procedure.category ilike 'Planned:%' then
          regexp_replace(procedure.category, '^Planned:\s*', '')
        when procedure.name like 'PM - %' then
          regexp_replace(procedure.name, '^PM - [^-]+ -\s*', '')
        else
          coalesce(procedure.description, procedure.name, 'Scheduled maintenance')
      end
    ) || ' - ' || coalesce(
      machinery.asset_identifier,
      vehicle.rego,
      'Asset'
    ),
    coalesce(procedure.description, 'Scheduled maintenance is due.'),
    'Open',
    'Medium',
    schedule.next_due_at::date,
    'Maintenance manager',
    'maintenance_schedule:' || schedule.id::text || ':' || schedule.next_due_at::date::text,
    null
  from public.operations_equipment_maintenance_schedules schedule
  left join public.operations_maintenance_procedures procedure
    on procedure.id = schedule.procedure_id
  left join public.operations_washing_equipment machinery
    on machinery.id = schedule.washing_equipment_id
  left join public.operations_vehicles vehicle
    on vehicle.id = schedule.vehicle_id
  where coalesce(schedule.is_active, true)
    and schedule.next_due_at is not null
    and schedule.next_due_at::date < current_date
  on conflict (automatic_key) where automatic_key is not null do nothing;

  get diagnostics maintenance_count = row_count;

  insert into public.operations_maintenance_tasks (
    source_type,
    source_module,
    source_record_type,
    source_record_id,
    target_type,
    target_record_id,
    target_label,
    title,
    description,
    status,
    priority,
    due_date,
    assigned_role,
    automatic_key,
    created_by
  )
  select
    'Inspection',
    'height_equipment',
    'height_inspection',
    inspection.id,
    'height_equipment',
    inspection.equipment_id,
    inspection.serial,
    'Height inspection failed - ' || inspection.serial,
    trim(
      coalesce(inspection.result, 'Failed inspection')
      || case
        when nullif(btrim(inspection.notes), '') is not null
          then E'\n' || btrim(inspection.notes)
        else ''
      end
    ),
    'Open',
    'Critical',
    coalesce(inspection.inspection_date, current_date),
    'Height equipment manager',
    'height_inspection:' || inspection.id::text,
    null
  from public.inspections inspection
  where inspection.result in (
    'Fail - Repair Required',
    'Fail - Remove From Service / Disposal'
  )
  on conflict (automatic_key) where automatic_key is not null do nothing;

  get diagnostics height_count = row_count;

  return jsonb_build_object(
    'maintenance_tasks_created', maintenance_count,
    'height_tasks_created', height_count
  );
end;
$function$
;

CREATE OR REPLACE FUNCTION public.operations_height_failure_task_v4077()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if new.result in (
    'Fail - Repair Required',
    'Fail - Remove From Service / Disposal'
  ) then
    perform public.operations_sync_automatic_tasks_v4077();
  elsif new.result = 'Pass' then
    update public.operations_maintenance_tasks
    set status = 'Completed',
        completed_at = now(),
        completed_by = auth.uid(),
        completion_notes = coalesce(
          completion_notes,
          'Closed automatically after a passing Height inspection.'
        )
    where source_module = 'height_equipment'
      and target_record_id = new.equipment_id
      and status <> 'Completed';
  end if;
  return new;
end;
$function$
;

-- Restore the captured broad function grants.
GRANT EXECUTE ON FUNCTION public.claim_preloaded_user_setup() TO PUBLIC, anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.operations_sync_automatic_tasks_v4077() TO PUBLIC, anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.operations_height_failure_task_v4077() TO PUBLIC, anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.operations_add_maintenance_record_v4053(date,uuid,uuid,jsonb,text,numeric,text,text,text,uuid) TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.operations_transfer_machinery_v4049(uuid,uuid,text,text,date,text,text,uuid) TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.operations_update_task_v4077(uuid,text,text,text,uuid) TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.spray_wash_has_role(text[]) TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.has_any_app_role(text[]) TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.has_app_role(text) TO anon, authenticated, service_role;

COMMIT;
