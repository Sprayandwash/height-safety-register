# Five-role verification checklist

Use separate test accounts. Do not test by changing the only production Admin account.

## Admin

- [ ] Can open every module.
- [ ] Can add/edit/remove role assignments.
- [ ] Can manage Height equipment, qualifications and certificates.
- [ ] Can manage vehicles, machinery, maintenance and tasks.
- [ ] Can upload and view company branding.

## Height equipment manager

- [ ] Can open Height Equipment and shared Height tasks.
- [ ] Can add/update equipment and inspections.
- [ ] Can add/delete equipment and inspection photos.
- [ ] Can add/update qualifications and certificates.
- [ ] Cannot open Maintenance or Vehicle Checks unless another role is also assigned.

## Height equipment user

- [ ] Can view equipment, inspection history, photos, qualifications and certificates.
- [ ] Cannot insert, update or delete Height rows through the UI.
- [ ] Direct Supabase attempts to insert/update/delete Height rows fail with RLS errors.
- [ ] Cannot upload, update or delete files in either Height storage bucket.

## Maintenance manager

- [ ] Can open Maintenance and load all lists without an RLS error.
- [ ] Can manage vehicles, machinery, procedures, schedules and maintenance history.
- [ ] Can create/update Maintenance tasks.
- [ ] Can upload asset photos under `operations-assets/`.
- [ ] Cannot create a Height inspection or write to Height storage paths.

## Vehicle inspector

- [ ] Can open Vehicle Checks and load the checklist.
- [ ] Can submit an inspection, answers and photos.
- [ ] An `Issue to report` creates a Maintenance-manager task.
- [ ] Can see only their own vehicle-check-created tasks unless directly assigned.
- [ ] Cannot manage vehicles, machinery, procedures or schedules.
- [ ] Cannot upload to `operations-assets/` or Height storage paths.

## Height task lifecycle

- [ ] Latest failed inspection creates one automatic task.
- [ ] Re-running sync does not duplicate it.
- [ ] A later pass closes that automatic task.
- [ ] A backdated pass does not close a task from a later failure.
- [ ] A manual Height task for the same equipment is not closed by a pass.
- [ ] A historical failure followed by a later pass is not recreated by hourly sync.

## Release evidence

- [ ] Post-migration verification CSV retained privately.
- [ ] Screenshots/results for each role retained privately.
- [ ] Cron run checked.
- [ ] Migration ledger updated.
- [ ] Rollback point recorded.
