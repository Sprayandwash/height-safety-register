# Spray & Wash V4.0.82 — Phase 0 Repair Review Package

This package is the reviewable repair deliverable produced from the live Phase 0 database export.

## Included

- `docs/LIVE-FINDINGS.md`
- `docs/POLICY-MATRIX.md`
- `docs/APPLY-RUNBOOK.md`
- `docs/ROLE-VERIFICATION-CHECKLIST.md`
- `docs/MIGRATION-LEDGER.md`
- `sql/00_preflight_gate.sql`
- `sql/01_phase0_database_stabilisation.sql`
- `sql/02_post_migration_verification.sql`
- `sql/90_full_rollback_to_20260730.sql`
- `evidence/EVIDENCE-MANIFEST.md`
- `CHECKSUMS-SHA256.txt`

## Important

No database or GitHub change has been made. Review the findings and SQL before application. The raw live exports are deliberately excluded because they contain private account and security information.
