# Migration ledger

| Migration | Live status before package | Repository status | Notes |
|---|---|---|---|
| Base Height schema | Confirmed live, version drift present | Present but stale per audit | Legacy role policies remained live. |
| Base Operations schema | Confirmed live, version drift present | Present but stale per audit | Legacy Operations roles remained in RLS. |
| V4.0.77 shared tasks and alerts | Confirmed live | Missing from repository at audit time | Functions, trigger, task fields/index and cron job confirmed. |
| 20260731 Phase 0 database stabilisation | Not applied | Review package only | Aligns five roles, RLS/storage, task lifecycle and RPC grants. |

After successful application, change the final row to **confirmed live**, commit the migration, and generate a new current-schema snapshot from Supabase.
